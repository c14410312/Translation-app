package dit.ie.translationapp;

/**
 * Created by dylan on 16/11/2016.
 */
public class ObjectDrawerItem {

    public int icon;
    public String name;

    //constructor
    public ObjectDrawerItem(int icon, String name){
        this.icon = icon;
        this.name = name;
    }
}
